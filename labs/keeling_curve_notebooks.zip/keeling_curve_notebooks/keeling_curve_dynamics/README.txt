Emissions-driven models of atmospheric CO2 — Notebook 2 of 2
November 19, 2026

Open keeling_curve_dynamics.ipynb in the course LEAP Jupyter environment.
Download just the notebook and run cells in order. The first cell retrieves
fixed data and the supplied carbon_models.py helper from the course GitHub repo.
No separate data-folder or helper download is needed. The first run needs internet
access; later runs reuse saved files offline. No GPU or Notebook 1 state is needed.
Required packages are in requirements.txt.

Fit 1958–2016 and compare 2017–2024. The notebook includes the quadratic+sine
baseline, one-box dynamics, a richer carbon response, five discussion prompts,
and an optional experiment changing future emissions. Allow about 40–50 minutes,
or demonstrate the richer model's final plots if time is short.

The richer model is a classroom adaptation of FaIR, not the full FaIR package.
