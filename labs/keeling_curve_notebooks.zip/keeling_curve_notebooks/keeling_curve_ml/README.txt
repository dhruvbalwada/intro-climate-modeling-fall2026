Fitting the Keeling curve — regression models (Notebook 1 of 2)
November 19, 2026

Open keeling_curve_ml.ipynb in the course LEAP Jupyter environment:
https://leap.2i2c.cloud/
Run the cells in order. The data cell downloads fixed classroom copies from our
course GitHub repository. No separate data-folder download is needed.
The first run needs internet access; later runs reuse the saved local files.
All code is supplied. Required packages are in requirements.txt. No GPU is needed.

The data are monthly atmospheric CO2 at Mauna Loa, 1958–2025, from the Scripps CO2
Program. These are station observations, not a global mean. Source version and
processing details are in data/provenance.json. Training uses years before 2017;
2017–2025 are held out for the classroom comparison.

Companion lesson: keeling_curve_dynamics/keeling_curve_dynamics.ipynb.
The combined download contains both folders. Notebook 2 runs independently,
recomputes quadratic-plus-sine as a baseline, and compares 2017–2024 because
the bundled historical emissions end in 2024. This notebook retains 2025.
