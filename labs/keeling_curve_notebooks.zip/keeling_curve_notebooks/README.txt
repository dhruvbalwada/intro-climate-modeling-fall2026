Keeling curve: two notebooks — November 19, 2026

For an online start, download either notebook alone; it retrieves its course files.
This optional package supplies both folders and all files for offline use.
Unzip it and keep the two notebook folders intact.
Open the notebooks in the course LEAP Jupyter environment, in this order:

1. keeling_curve_ml/keeling_curve_ml.ipynb
   Fit regression models and compare training with later-year prediction error.
2. keeling_curve_dynamics/keeling_curve_dynamics.ipynb
   Refit quadratic+sine as a baseline; compare one-box and richer carbon dynamics;
   prescribe different future emissions and interpret the responses.

Each notebook runs independently. All code and fixed data are supplied.
The second folder must keep carbon_models.py and data beside its notebook.
Install packages listed in requirements.txt if your environment needs them.
No GPU or network access is needed once these packages are available.

Each folder also contains an HTML reading view with the computed plots.
Student notebooks have blank responses and empty code outputs.

Notebook 1 retains concentration observations through 2025. Notebook 2 uses
1958–2024 because historical emissions end in 2024; it fits before 2017 and
refits its regression baseline on that same training period. Its later-period
scores therefore cover 2017–2024. Source details are in the data folders.
