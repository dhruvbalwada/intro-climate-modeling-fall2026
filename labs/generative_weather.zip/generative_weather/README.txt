Generating synthetic weather — Introduction to Climate Modeling

Unzip the lab and open generative_weather.ipynb in the course LEAP Jupyter environment.
Keep the data folder beside it. All code is supplied; answer the four short prompts.
Allow about 25–35 minutes. The final persistence experiment is optional.

Requires NumPy, pandas, and Matplotlib; see requirements.txt. No GPU is needed.
The package contains the same fixed NYC station data used in Lab 0c and runs offline.
If the file is missing, the notebook can download that exact version on its first run.

Training: 1995–2009. Evaluation: 2010–2014. The source file contains both observations
and ERA5, but the lab uses only the observed temperature column, t_obs.
Source details and checksum: data/provenance.json.
