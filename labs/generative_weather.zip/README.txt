Generating synthetic weather — Introduction to Climate Modeling
Revised November 19, 2026

Open generative_weather.ipynb in the course LEAP Jupyter environment and run
cells in order. All code is supplied. Make the predictions and answer the four
Lab questions. Allow about 30–40 minutes; the final memory experiment is optional.

The notebook can be downloaded on its own: its first data-reading cell retrieves
a fixed version from the course GitHub and caches it in data/. Internet is needed
for that first download. The optional ZIP includes the data for offline use.
Requires NumPy, pandas, and Matplotlib; see requirements.txt. No GPU is needed.

Training: 1995–2009. Evaluation: 2010–2014. The file contains observations and ERA5,
but this lab uses only observed Central Park temperature, t_obs, defined as the
average of daily maximum and minimum temperature in degrees Celsius.
Source details and checksum: data/provenance.json.

Compare independent and persistent generators with the same seasonal mean and
spread. Evaluate histograms, lag correlations, hot-day counts, and hot-spell lengths.
The generator samples a fixed seasonal climate, not emissions-driven climate change.
