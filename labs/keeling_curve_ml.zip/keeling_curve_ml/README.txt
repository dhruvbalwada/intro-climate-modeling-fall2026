Fitting the Keeling curve — November 12, 2026

Unzip the lab, keep the data folder beside keeling_curve_ml.ipynb, and open the
notebook in the course LEAP Jupyter environment: https://leap.2i2c.cloud/
Run the cells in order. All code is supplied. Write brief answers at the four prompts.

The bundled data allow offline execution once the Python packages are available.
If the data file is missing, the notebook downloads the fixed source version.
Required packages are listed in requirements.txt; a GPU and Colab login are not needed.

The data are monthly atmospheric CO2 at Mauna Loa, 1958–2025, from the Scripps CO2
Program. These are station observations, not a global mean. Source version and
processing details are in data/provenance.json. Training uses years before 2017;
2017–2025 are held out for the classroom comparison.
